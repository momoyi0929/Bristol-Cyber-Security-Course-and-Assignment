# File Integrity Checker

A secure command-line tool for computing and verifying cryptographic hashes of files using OpenSSL.

**Author:** Yi Li (Student ID: 2829967)  
**Module:** Foundations of Cyber Security (MSc) - COMSM0118_2025_TB-1  
**Date:** October 2025

## Overview

This tool computes cryptographic hashes of files and verifies their integrity against expected hash values. It uses streaming I/O to handle files of any size with constant memory usage (~4KB), making it suitable for processing everything from small text files to multi-gigabyte archives.

## Features

- **Multiple Hash Algorithms**: Supports SHA-256 (default) and SHA-512
- **Memory Efficient**: Streams files in 4KB chunks for constant memory usage
- **Integrity Verification**: Compares computed hashes against expected values
- **Performance Tracking**: Reports execution time for each operation
- **Comprehensive Error Handling**: Validates inputs and handles errors gracefully
- **Color-Coded Output**: Visual feedback for pass/fail results

## Dependencies

### System Requirements
- Linux, macOS, or Unix-like operating system


### Installing Dependencies

**Ubuntu/Debian:**
```bash
sudo apt-get update
sudo apt-get install build-essential libssl-dev
```

**macOS (using Homebrew):**
```bash
brew install openssl
```

## Compilation

The project includes a Makefile for easy compilation.

### Build the Program
```bash
make
```

This compiles `filehash.c` and creates the `filehash` executable.

### Clean Build Artifacts
```bash
make clean
```

### Compiler Flags Used
- `-Wall -Wextra`: Enable comprehensive warnings
- `-lssl -lcrypto`: Link against OpenSSL libraries
- `-O2`: Optimization level 2 for better performance

## Usage

### Command-Line Options

| Option | Description |
|--------|-------------|
| `-a <algorithm>` | Specify hashing algorithm (sha256 or sha512) |
| `-h, --help` | Display help information |

### Supported Algorithms

| Algorithm | Hash Length | Hex Characters | Security Level |
|-----------|-------------|----------------|----------------|
| SHA-256 (default) | 256 bits (32 bytes) | 64 | 2^128 collision resistance |
| SHA-512 | 512 bits (64 bytes) | 128 | 2^256 collision resistance |

### Basic Syntax
```bash
./filehash [-a algorithm] <filename> [expected_hash]
```

### Examples

#### 1. Compute Hash (Default SHA-256)
```bash
./filehash myfile.txt
```
**Output:**
```
Using algorithm: sha256
Processing file: myfile.txt
Computed hash: 2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae
Process completed in 0.0003 seconds
```

#### 2. Compute SHA-512 Hash
```bash
./filehash -a sha512 myfile.txt
```

#### 3. Verify File Integrity
```bash
./filehash myfile.txt 2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae
```
**Output (if hash matches):**
```
Using algorithm: sha256
Processing file: myfile.txt
Expected hash: 2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae
Computed hash: 2c26b46b68ffc68ff99b453c1d30413413422d706483bfa0f98a5e886266e7ae
Integrity check: PASS - File is intact
Process completed in 0.0003 seconds
```

#### 4. Display Help
```bash
./filehash -h
```

## Performance Benchmarks

Based on testing on a modern 64-bit system:

| File Size | SHA-256 | SHA-512 | SHA-512 Advantage |
|-----------|---------|---------|-------------------|
| 1 KB | 0.0003s | 0.0004s | -25% (SHA-256 faster) |
| 1 MB | 0.0061s | 0.0046s | +25% |
| 100 MB | 0.3118s | 0.2081s | +33% |
| 1 GB | 2.9928s | 2.0554s | +31% |

**Note:** SHA-512 performs significantly better on large files due to 64-bit optimization on modern processors.

## Architecture

### Module Structure

```
┌─────────────────────────────────────┐
│         Main Function               │
│  (Orchestrates entire process)      │
└──────────────┬──────────────────────┘
               │
       ┌───────┴────────┐
       │                │
┌──────▼─────┐   ┌─────▼──────┐
│   Core     │   │  Utility   │
│   Logic    │   │  Functions │   
│  Module    │   └────────────┘
└──────┬─────┘
       │
┌──────▼─────────┐
│   Hashing      │
│   Module       │
└────────────────┘
```

### Function Overview

**Core Logic:**
- `parse_arguments()`: Command-line argument parsing
- `validate_inputs()`: Input validation and security checks
- `run_hash_process()`: Main workflow orchestration

**Hashing:**
- `is_valid_algorithm()`: Algorithm validation
- `compute_file_hash()`: Streaming hash computation
- `verify_hash()`: Hash comparison and verification
- `print_hash_hex()`: Hexadecimal output formatting

**Utility:**
- `print_usage()`: Help information display
- `print_supported_algorithms()`: Algorithm listing


## Known Limitations
- Uses `strcasecmp()` for hash comparison (potential timing attack vulnerability)
- No SHA-3 support
- Single-threaded processing (no parallel optimization)

## Testing

### Test Cases Covered
1. Small files (< 1KB)
2. Medium files (1MB - 100MB)
3. Large files (> 1GB)
4. Invalid algorithm names
5. Non-existent files
6. Malformed hash values
7. Case-insensitive hash verification
8. Both SHA-256 and SHA-512 algorithms

### Test Samples

The experiment tests 4 size of files including 1KB, 1MB, 100MB, 1GB, which are generated by the code shown in the report.

## AI Usage Declaration

In accordance with assignment requirements, AI assistance was used in the following ways:
- Learning C language syntax and best practices
- Understanding OpenSSL API documentation
- Structuring code architecture and modular design
- Improving code comments and documentation
- Reviewing error handling patterns

**All core implementation logic, cryptographic operations, and final code represent my own work and understanding.**




