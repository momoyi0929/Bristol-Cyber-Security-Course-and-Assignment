/**
 * File Integrity Checker
 * 
 * A command-line tool for computing and verifying cryptographic hashes of files.
 * Uses OpenSSL's low-level API (SHA256/SHA512) with streaming for large file support.
 * 
 * Features:
 *   - Supports SHA-256 and SHA-512 hashing algorithms
 *   - Streams files in 4KB(4096) chunks for constant memory usage
 *   - Verifies file integrity against expected hash values
 *   - Comprehensive error handling and input validation
 * 
 * Author: Yi Li
 * Module: Foundations of Cyber Security (MSc)
 * Date: October 2025
 # Student no: 282996
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <openssl/sha.h>
#include <ctype.h>

// used for printing color
#define GREEN "\033[1;32m"
#define RED   "\033[1;31m"
#define RESET "\033[0m"

#define BUFFER_SIZE 4096
#define MAX_HASH_LEN 64  // SHA-512 produces 64 bytes

// Core logic functions
int parse_arguments(int argc, char *argv[], const char **algorithm, const char **filename, const char **expected_hash);
int validate_inputs(const char *algorithm, const char *filename, const char *expected_hash);
int run_hash_process(const char *filename, const char *algorithm, const char *expected_hash);

// Hashing functions
int is_valid_algorithm(const char *algorithm);
int compute_file_hash(const char *filename, const char *algorithm, unsigned char *hash, unsigned int *hash_len);
void print_hash_hex(const unsigned char *hash, unsigned int hash_len);
int verify_hash(const unsigned char *computed_hash, unsigned int computed_len, const char *expected_hash);

// Function declarations
void print_usage(const char *program_name);
void print_supported_algorithms(void);

//
// ======================= MAIN FUNCTION =======================
//
int main(int argc, char *argv[]) {
    const char *algorithm = "sha256";
    const char *filename = NULL;
    const char *expected_hash = NULL;

    // Step 1: Parse arguments
    if (!parse_arguments(argc, argv, &algorithm, &filename, &expected_hash)) {
        return 1;
    }

    // Step 2: Validate inputs
    if (!validate_inputs(algorithm, filename, expected_hash)) {
        return 1;
    }

    // Step 3: Execute hashing and verification
    return run_hash_process(filename, algorithm, expected_hash);
}

//
// ======================= CORE LOGIC FUNCTIONS =======================
//

int parse_arguments(int argc, char *argv[], const char **algorithm,
                    const char **filename, const char **expected_hash) {
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-a") == 0) {
            if (i + 1 < argc) {
                *algorithm = argv[++i];
            } else {
                fprintf(stderr, RED "Error: -a option requires an algorithm name\n" RESET);
                print_usage(argv[0]);
                return 0;
            }
        } else if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0) {
            print_usage(argv[0]);
            exit(0);
        } else if (*filename == NULL) {
            *filename = argv[i];
        } else if (*expected_hash == NULL) {
            *expected_hash = argv[i];
        } else {
            fprintf(stderr, RED "Error: Too many arguments\n" RESET);
            print_usage(argv[0]);
            return 0;
        }
    }

    if (*filename == NULL) {
        fprintf(stderr, RED "Error: No filename provided\n" RESET);
        print_usage(argv[0]);
        return 0;
    }

    return 1;
}

int validate_inputs(const char *algorithm, const char *filename, const char *expected_hash) {
    if (!is_valid_algorithm(algorithm)) {
        fprintf(stderr, RED "Error: Unsupported algorithm '%s'\n" RESET, algorithm);
        fprintf(stderr, "Supported algorithms:\n");
        print_supported_algorithms();
        return 0;
    }

    if (expected_hash && strlen(expected_hash) > 0) {
        for (size_t i = 0; i < strlen(expected_hash); i++) {
            if (!isxdigit(expected_hash[i])) {
                fprintf(stderr, RED "Error: Expected hash contains non-hex characters\n" RESET);
                return 0;
            }
        }
    }

    return 1;
}

int run_hash_process(const char *filename, const char *algorithm, const char *expected_hash) {
    unsigned char computed_hash[MAX_HASH_LEN];
    unsigned int hash_length = 0;

    printf("Using algorithm: %s\n", algorithm);
    printf("Processing file: %s\n", filename);
    if (expected_hash) printf("Expected hash: %s\n", expected_hash);

    if (compute_file_hash(filename, algorithm, computed_hash, &hash_length) != 0) {
        fprintf(stderr, RED "Failed to compute hash for file '%s'\n" RESET, filename);
        return 1;
    }

    printf("Computed hash: ");
    print_hash_hex(computed_hash, hash_length);
    printf("\n");

    if (expected_hash) {
        if (verify_hash(computed_hash, hash_length, expected_hash) == 0) {
            printf(GREEN "Integrity check: PASS - File is intact\n" RESET);
            return 0;
        } else {
            printf(RED "Integrity check: FAIL - Hash mismatch\n" RESET);
            return 1;
        }
    }

    return 0;
}

//
// ======================= HASHING FUNCTIONS =======================
//

int is_valid_algorithm(const char *algorithm) {
    if (algorithm == NULL) return 0;

    return (strcasecmp(algorithm, "sha256") == 0 ||
            strcasecmp(algorithm, "sha512") == 0);
}

int compute_file_hash(const char *filename, const char *algorithm,
                     unsigned char *hash, unsigned int *hash_len) {
    FILE *file = fopen(filename, "rb");
    if (!file) {
        perror("Error opening file");
        return 1;
    }

    unsigned char buffer[BUFFER_SIZE];
    size_t bytes_read;

    if (strcasecmp(algorithm, "sha256") == 0) {
        SHA256_CTX ctx;
        *hash_len = SHA256_DIGEST_LENGTH;

        if (!SHA256_Init(&ctx)) { fclose(file); return 1; }
        while ((bytes_read = fread(buffer, 1, BUFFER_SIZE, file)) > 0) {
            if (!SHA256_Update(&ctx, buffer, bytes_read)) { fclose(file); return 1; }
        }
        if (!SHA256_Final(hash, &ctx)) { fclose(file); return 1; }

    } else if (strcasecmp(algorithm, "sha512") == 0) {
        SHA512_CTX ctx;
        *hash_len = SHA512_DIGEST_LENGTH;

        if (!SHA512_Init(&ctx)) { fclose(file); return 1; }
        while ((bytes_read = fread(buffer, 1, BUFFER_SIZE, file)) > 0) {
            if (!SHA512_Update(&ctx, buffer, bytes_read)) { fclose(file); return 1; }
        }
        if (!SHA512_Final(hash, &ctx)) { fclose(file); return 1; }

    } else {
        fprintf(stderr, RED "Error: Unsupported algorithm '%s'\n" RESET, algorithm);
        fclose(file);
        return 1;
    }

    fclose(file);
    return 0;
}

void print_hash_hex(const unsigned char *hash, unsigned int hash_len) {
    for (unsigned int i = 0; i < hash_len; i++) {
        printf("%02x", hash[i]);
    }
}

int verify_hash(const unsigned char *computed_hash, unsigned int computed_len,
               const char *expected_hash) {
    char computed_hex[computed_len * 2 + 1];
    for (unsigned int i = 0; i < computed_len; i++) {
        sprintf(computed_hex + i * 2, "%02x", computed_hash[i]);
    }
    computed_hex[computed_len * 2] = '\0';

    if (strcasecmp(computed_hex, expected_hash) == 0)
        return 0;
    else {
        printf("Expected: %s\n", expected_hash);
        printf("Computed: %s\n", computed_hex);
        return 1;
    }
}

//
// ======================= UTILITY FUNCTIONS =======================
//

void print_usage(const char *program_name) {
    printf("Usage: %s [-a algorithm] filename [expected_hash]\n\n", program_name);
    printf("Options:\n");
    printf("  -a algorithm  Specify hashing algorithm (default: sha256)\n");
    printf("  -h, --help    Show this help message\n\n");
    printf("Supported algorithms:\n");
    print_supported_algorithms();
    printf("\nExamples:\n");
    printf("  %s myfile.txt\n", program_name);
    printf("  %s -a sha512 myfile.txt\n", program_name);
    printf("  %s myfile.txt 2c26b46911185131006145e7e22b6f651a87667c\n", program_name);
}

void print_supported_algorithms(void) {
    printf("  sha256 (default) - 256-bit hash (64 hex chars)\n");
    printf("  sha512          - 512-bit hash (128 hex chars)\n");
}
